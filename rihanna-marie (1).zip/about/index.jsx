import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Header1 } from "./components/Header1";
import { Stats1 } from "./components/Stats1";
import { Timeline8 } from "./components/Timeline8";
import { Cta25 } from "./components/Cta25";
import { Footer11 } from "./components/Footer11";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Header1 />
      <Stats1 />
      <Timeline8 />
      <Cta25 />
      <Footer11 />
    </div>
  );
}
