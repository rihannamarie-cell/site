"use client";

import { Button } from "@relume_io/relume-ui";
import { motion, useScroll, useTransform } from "framer-motion";
import React, { useRef } from "react";
import { RxChevronRight } from "react-icons/rx";

const Circle = () => {
  const circleRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: circleRef,
    offset: ["end end", "end center"],
  });
  const backgroundColor = {
    backgroundColor: useTransform(scrollYProgress, [0.85, 1], ["#ccc", "#000"]),
  };
  return (
    <div className="absolute left-0 -ml-5 flex h-full w-5 items-start justify-center md:left-auto md:-ml-8 md:w-8">
      <motion.div
        ref={circleRef}
        style={backgroundColor}
        className="z-20 mt-9 size-[0.9375rem] rounded-full shadow-[0_0_0_8px_white] md:mt-12"
      />
    </div>
  );
};

export function Timeline8() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container max-w-lg">
        <div className="mb-12 md:mb-18 lg:mb-20">
          <div className="relative z-10 w-full max-w-lg">
            <p className="mb-3 font-semibold md:mb-4">Story</p>
            <h2 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
              The path from the salon floor to your dispensary
            </h2>
            <p className="md:text-md">
              Every step taught me something about service, systems, and showing
              up. This is how I got here.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-4 md:mt-8">
              <Button title="Work" variant="secondary">
                Work
              </Button>
              <Button
                title="Contact"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Contact
              </Button>
            </div>
          </div>
        </div>
        <div className="grid w-full max-w-lg auto-cols-fr grid-cols-[max-content_1fr] items-start justify-items-center">
          <div className="relative left-0 flex h-full w-5 flex-col items-center md:left-auto md:w-8">
            <div className="absolute z-10 h-16 w-1 bg-gradient-to-b from-background-primary to-transparent" />
            <div className="sticky top-0 mt-[-50vh] h-[50vh] w-[3px] bg-neutral-black" />
            <div className="h-full w-[3px] bg-neutral-lighter" />
            <div className="absolute bottom-0 z-0 h-16 w-1 bg-gradient-to-b from-transparent to-background-primary" />
            <div className="absolute top-[-50vh] h-[50vh] w-full bg-background-primary" />
          </div>
          <div className="grid auto-cols-fr grid-cols-1 gap-y-8 sm:gap-12 md:gap-20">
            <div className="relative">
              <Circle />
              <div className="ml-4 flex flex-col border border-border-primary md:ml-12">
                <div className="p-6 md:p-8">
                  <h3 className="mb-3 text-4xl font-bold leading-[1.2] md:mb-4 md:text-5xl lg:text-6xl">
                    Roots
                  </h3>
                  <h4 className="mb-3 text-xl font-bold md:mb-4 md:text-2xl">
                    Where it started
                  </h4>
                  <p>
                    I grew up helping my mom at her hair salon. Sweeping floors,
                    cleaning stations, and watching her truly listen to clients,
                    solve their problems on the spot, and make everyone feel
                    seen. That’s where I first learned that service means
                    showing up for people. In college, I volunteered at a local
                    animal shelter, helping pets find their fur-ever homes and
                    reuniting owners with their lost companions. In college, I
                    started using cannabis to help me sleep and focus, so I
                    could get things done and be present for what mattered.
                  </p>
                  <div className="mt-6 flex flex-wrap items-center gap-4 md:mt-8">
                    <Button variant="secondary">Work</Button>
                    <Button
                      variant="link"
                      size="link"
                      iconRight={<RxChevronRight />}
                    >
                      Contact
                    </Button>
                  </div>
                </div>
                <div className="overflow-hidden">
                  <img
                    className="w-full"
                    src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                    alt="Relume placeholder image 1"
                  />
                </div>
              </div>
            </div>
            <div className="relative">
              <Circle />
              <div className="ml-4 flex flex-col border border-border-primary md:ml-12">
                <div className="p-6 md:p-8">
                  <h3 className="mb-3 text-4xl font-bold leading-[1.2] md:mb-4 md:text-5xl lg:text-6xl">
                    2017
                  </h3>
                  <h4 className="mb-3 text-xl font-bold md:mb-4 md:text-2xl">
                    The cannabis chapter
                  </h4>
                  <p>
                    I began at Harborside in Oakland as a budtender right after
                    college. As a call center associate and budtender, I had the
                    privilege of assisting thousands of patients with products
                    addressing various health issues. This role was one of the
                    most rewarding I’ve held. Over time, I advanced into
                    leadership positions, which helped me grow my skills in
                    software, people management, and operations. I started
                    working there under Prop 215 and deepened my involvement
                    when Prop 64 took effect.
                  </p>
                </div>
                <div className="overflow-hidden">
                  <img
                    className="w-full"
                    src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                    alt="Relume placeholder image 2"
                  />
                </div>
              </div>
            </div>
            <div className="relative">
              <Circle />
              <div className="ml-4 flex flex-col border border-border-primary md:ml-12">
                <div className="p-6 md:p-8">
                  <h3 className="mb-3 text-4xl font-bold leading-[1.2] md:mb-4 md:text-5xl lg:text-6xl">
                    Shift
                  </h3>
                  <h4 className="mb-3 text-xl font-bold md:mb-4 md:text-2xl">
                    The lightbulb moment
                  </h4>
                  <p>
                    Five years after cannabis was legalized in California and
                    after working in three shops, I saw small dispensaries
                    hitting the same walls over and over. Outdated menus, broken
                    workflows, no time to fix any of it. I realized I could be
                    the one to step in and handle it.
                  </p>
                </div>
                <div className="overflow-hidden">
                  <img
                    className="w-full"
                    src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                    alt="Relume placeholder image 3"
                  />
                </div>
              </div>
            </div>
            <div className="relative">
              <Circle />
              <div className="ml-4 flex flex-col border border-border-primary md:ml-12">
                <div className="p-6 md:p-8">
                  <h3 className="mb-3 text-4xl font-bold leading-[1.2] md:mb-4 md:text-5xl lg:text-6xl">
                    Today
                  </h3>
                  <h4 className="mb-3 text-xl font-bold md:mb-4 md:text-2xl">
                    Your dedicated support
                  </h4>
                  <p>
                    I am one person who shows up consistently for your
                    dispensary. No account managers, no handoffs. Just me, your
                    to-do list, and the experience to get it done.
                  </p>
                  <div className="mt-6 flex flex-wrap items-center gap-4 md:mt-8">
                    <Button variant="secondary">Work</Button>
                    <Button
                      variant="link"
                      size="link"
                      iconRight={<RxChevronRight />}
                    >
                      Contact
                    </Button>
                  </div>
                </div>
                <div className="overflow-hidden">
                  <img
                    className="w-full"
                    src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                    alt="Relume placeholder image 4"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
