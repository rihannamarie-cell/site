import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Header62 } from "./components/Header62";
import { Portfolio8 } from "./components/Portfolio8";
import { Portfolio9 } from "./components/Portfolio9";
import { Cta25 } from "./components/Cta25";
import { Footer11 } from "./components/Footer11";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Header62 />
      <Portfolio8 />
      <Portfolio9 />
      <Cta25 />
      <Footer11 />
    </div>
  );
}
