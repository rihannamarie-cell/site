"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";

export function Cta25() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container max-w-lg text-center">
        <h2 className="rb-5 mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
          Want to be the next project on this page?
        </h2>
        <p className="md:text-md">
          Let's build something that makes your team breathe easier and your
          customers stick around.
        </p>
        <div className="mt-6 flex items-center justify-center gap-4 md:mt-8">
          <Button title="Start now">Start now</Button>
          <Button title="Services" variant="secondary">
            Services
          </Button>
        </div>
      </div>
    </section>
  );
}
