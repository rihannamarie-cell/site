import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Header1 } from "./components/Header1";
import { Stats8 } from "./components/Stats8";
import { Layout140 } from "./components/Layout140";
import { Layout401 } from "./components/Layout401";
import { Portfolio11 } from "./components/Portfolio11";
import { Cta25 } from "./components/Cta25";
import { Footer11 } from "./components/Footer11";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Header1 />
      <Stats8 />
      <Layout140 />
      <Layout401 />
      <Portfolio11 />
      <Cta25 />
      <Footer11 />
    </div>
  );
}
