"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";

export function Header1() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="grid grid-cols-1 gap-x-20 gap-y-12 md:gap-y-16 lg:grid-cols-2 lg:items-center">
          <div>
            <h1 className="mb-5 text-6xl font-bold md:mb-6 md:text-9xl lg:text-10xl">
              Your to-do list, handled
            </h1>
            <p className="md:text-md">
              I help small California cannabis dispensaries manage their
              eCommerce so you can get back to the floor. One person, showing up
              consistently, tackling the digital work that piles up.
            </p>
            <div className="mt-6 flex flex-wrap gap-4 md:mt-8">
              <Button title="See my work">See my work</Button>
              <Button title="Get in contact" variant="secondary">
                Get in contact
              </Button>
            </div>
          </div>
          <div>
            <img
              src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
              className="w-full object-cover"
              alt="Relume placeholder image"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
