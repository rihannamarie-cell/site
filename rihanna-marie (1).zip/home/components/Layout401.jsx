"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Layout401() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mb-12 md:mb-18 lg:mb-20">
          <div className="mx-auto max-w-lg text-center">
            <p className="mb-3 font-semibold md:mb-4">Services</p>
            <h1 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
              What I handle
            </h1>
            <p className="md:text-md">
              Digital work built for small shops, not big budgets.
            </p>
          </div>
        </div>
        <div className="grid auto-cols-fr grid-cols-1 gap-6 sm:grid-cols-2 md:gap-8 lg:grid-cols-4">
          <div className="flex flex-col justify-center border border-border-primary p-6">
            <div className="mb-3 md:mb-4">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                className="size-12"
                alt="Relume logo 1"
              />
            </div>
            <h3 className="mb-2 text-lg font-bold leading-[1.4] md:text-2xl">
              eCommerce design and build
            </h3>
            <p>
              Treez eCommerce and Wordpress websites that load fast and sell
              faster.
            </p>
            <div className="mt-5 md:mt-6">
              <Button
                title="Services"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Services
              </Button>
            </div>
          </div>
          <div className="flex flex-col justify-center border border-border-primary p-6">
            <div className="mb-3 md:mb-4">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                className="size-12"
                alt="Relume logo 1"
              />
            </div>
            <h3 className="mb-2 text-lg font-bold leading-[1.4] md:text-2xl">
              UI/UX and brand experience
            </h3>
            <p>
              Interfaces that feel like your shop, intuitive and unmistakably
              yours.
            </p>
            <div className="mt-5 md:mt-6">
              <Button
                title="Services"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Services
              </Button>
            </div>
          </div>
          <div className="flex flex-col justify-center border border-border-primary p-6">
            <div className="mb-3 md:mb-4">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                className="size-12"
                alt="Relume logo 1"
              />
            </div>
            <h3 className="mb-2 text-lg font-bold leading-[1.4] md:text-2xl">
              Retail ops and CRM
            </h3>
            <p>Loyalty, email, and inventory workflows that run without you.</p>
            <div className="mt-5 md:mt-6">
              <Button
                title="Services"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Services
              </Button>
            </div>
          </div>
          <div className="flex flex-col justify-center border border-border-primary p-6">
            <div className="mb-3 md:mb-4">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                className="size-12"
                alt="Relume logo 1"
              />
            </div>
            <h3 className="mb-2 text-lg font-bold leading-[1.4] md:text-2xl">
              Ongoing support and maintenance
            </h3>
            <p>A consistent second set of hands for the daily digital grind.</p>
            <div className="mt-5 md:mt-6">
              <Button
                title="Services"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Services
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
