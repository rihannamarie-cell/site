"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Layout140() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container max-w-lg text-center">
        <p className="mb-3 font-semibold md:mb-4">Specialties</p>
        <p className="mb-5 text-lg font-bold leading-[1.4] md:mb-6 md:text-2xl">
          The tools and tasks I reach for most. Alpine IQ Support · Systems
          Integration · Google Search Console Setup & Maintenance · Product Card
          Optimization · Treez eCommerce Design · eCommerce Design & Migration ·
          Phone Tree Setup
        </p>
        <div className="mt-6 flex items-center justify-center gap-x-4 md:mt-8">
          <Button title="Services" variant="secondary">
            Services
          </Button>
          <Button
            title="My Work"
            variant="link"
            size="link"
            iconRight={<RxChevronRight />}
          >
            My Work
          </Button>
        </div>
      </div>
    </section>
  );
}
