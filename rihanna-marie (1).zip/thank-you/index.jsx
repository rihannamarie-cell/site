import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Footer11 } from "./components/Footer11";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Footer11 />
    </div>
  );
}
