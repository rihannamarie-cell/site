import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Layout353 } from "./components/Layout353";
import { Cta13 } from "./components/Cta13";
import { Footer11 } from "./components/Footer11";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Layout353 />
      <Cta13 />
      <Footer11 />
    </div>
  );
}
